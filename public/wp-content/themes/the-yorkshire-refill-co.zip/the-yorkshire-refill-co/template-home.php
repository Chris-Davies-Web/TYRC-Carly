<?php 

/*
Template Name: Home Page
*/

get_header(); ?>

		<div class="content-area home">
			<main>
				<section class="hero">
					<div class="container">	
						<div class="row">
							<div class="col-12 col-md-6">
								<img src="<?php echo get_theme_mod('set_hero_image'); ?>" />
							</div>
							<div class="col-12 col-md-6">
								<div class="copy-container">
									<h1><?php echo get_theme_mod('set_hero_text'); ?></h1>
									<div class="cta cta-primary">
										<a href='<?php echo get_theme_mod('set_hero_cta_url'); ?>'><?php echo get_theme_mod('set_hero_cta_text'); ?></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="how-we-work">
					<div class="container">	
						<div class="row">
							<h2><?php echo get_theme_mod('set_how_we_work_header'); ?></h2>
						</div>
						
						<div class="row">
							<div class="col-12 col-md-6 col-lg-3 reveal" data-delay="200">
								<p class="step">Step 1</p>
								<div class="step--image-container">
									<img src="<?php echo get_theme_mod('set_how_we_work_image_step_1'); ?>" />
								</div>
								<h5><?php echo get_theme_mod('set_how_we_work_step_title1'); ?></h5>
								<p class="description">
								<?php echo get_theme_mod('set_how_we_work_step_description1'); ?>
								</p>
							</div>
							<div class="col-12 col-md-6 col-lg-3 reveal" data-delay="600">
								<p class="step">Step 2</p>
								<div class="step--image-container">
									<img src="<?php echo get_theme_mod('set_how_we_work_image_step_2'); ?>" />
								</div>
								<h5><?php echo get_theme_mod('set_how_we_work_step_title2'); ?></h5>
								<p class="description">
								<?php echo get_theme_mod('set_how_we_work_step_description2'); ?>
								</p>
							</div>
							<div class="col-12 col-md-6 col-lg-3 reveal" data-delay="1000">
								<p class="step">Step 3</p>
								<div class="step--image-container">
									<img src="<?php echo get_theme_mod('set_how_we_work_image_step_3'); ?>" />
								</div>
								<h5><?php echo get_theme_mod('set_how_we_work_step_title3'); ?></h5>
								<p class="description">
								<?php echo get_theme_mod('set_how_we_work_step_description3'); ?>
								</p>
							</div>
							<div class="col-12 col-md-6 col-lg-3 reveal" data-delay="1400">
								<p class="step">Step 4</p>
								<div class="step--image-container">
									<img src="<?php echo get_theme_mod('set_how_we_work_image_step_4'); ?>" />
								</div>
								<h5><?php echo get_theme_mod('set_how_we_work_step_title4'); ?></h5>
								<p class="description">
								<?php echo get_theme_mod('set_how_we_work_step_description4'); ?>
								</p>
							</div>
						</div> 
						
						<div class="row">
							<div class="cta cta-secondary">
								<a href='<?php echo get_theme_mod('set_how_we_work_CTA_url'); ?>'><?php echo get_theme_mod('set_how_we_work_CTA_copy'); ?></a>
							</div>
						</div>
					</div>
				</section>
				<?php 
				/*----------------------------------------------------------------------------------------------*/
				// We'll only show these sections if WooCommerce is active
				if( class_exists( 'WooCommerce' ) ): 
					$show_popular_product_carousel = get_theme_mod( 'set_show_popular_products', 0 );
					if( $show_popular_product_carousel == 1):
				?>
						<?php 
						$popular_products_color_theme = get_theme_mod( 'set_popular_colour_theme', 'dark' );
						$popular_products_title = get_theme_mod( 'set_popular_title');
						$popular_products_set_number_of_products = get_theme_mod( 'set_popular_num_products');

						echo do_shortcode('[flexslider_carousel color_theme="'.$popular_products_color_theme.'" title="'.$popular_products_title.'" number_of_products="'.$popular_products_set_number_of_products.'" sort_type="favourites"]'); 
						?>
						<?php 

					endif;

						// Getting data from Customizer to display the Promotion Section
						$showPromotion		= get_theme_mod( 'set_promotion_show', 0 );
						$promo 				= get_theme_mod( 'set_promotion' );
						$currency			= get_woocommerce_currency_symbol();
						$regular			= get_post_meta( $promo, '_regular_price', true );
						$sale 				= get_post_meta( $promo, '_sale_price', true );

						// We'll only show this section if the user chooses to do so and if some promo product is set
						if( $showPromotion == 1 && ( !empty( $promo ) ) ):
							
						?>
						<section class="product-promotion <?php echo get_theme_mod( 'set_promotion_colour_theme', 'white' ); ?>">
							<div class="container">
								<div class="section-title">
									<h2><?php echo get_theme_mod( 'set_promotion_title', 'Deal of the Week' ); ?></h2>
								</div>
								<div class="row d-flex align-items-center">
									<div class="deal-img col-md-6 col-12 ml-auto text-center">
										<a href="<?php echo get_permalink( $promo ); ?>">
										<?php echo get_the_post_thumbnail( $promo, 'large', array( 'class' => 'img-fluid' ) ); ?>
										</a>
									</div>
									<div class="deal-desc col-md-4 col-12 mr-auto text-center">
										<?php if( !empty( $sale ) ): ?>
											<span class="discount">
                                                <?php 
                                                   $discount_percentage = absint( 100 - ( ( $sale/$regular ) * 100 ) );echo $discount_percentage . '% OFF'; 
                                                ?>
											</span>
										<?php endif; ?>
										<h3>
											<a href="<?php echo get_permalink( $promo ); ?>"><?php echo get_the_title( $promo ); ?></a>
										</h3>
										<p><?php echo get_the_excerpt( $promo ); ?></p>
										<div class="prices">
											<span class="regular">
												<?php 
												 echo $currency;
												 echo $regular;
												?>
											</span>
											<?php if( !empty( $sale ) ): ?>
												<span class="sale">
													<?php 
													echo $currency;
													echo $sale;
													?>										
												</span>
											<?php endif; ?>
										</div>
										<a href="<?php echo esc_url( '?add-to-cart=' . $promo ); ?>" class="add-to-cart">Add to Cart</a>
									</div>
								</div>
							</div> 
						</section>
						<?php  endif; 
						
						// New Products Carousel
						$show_new_product_carousel = get_theme_mod( 'set_show_new_products', 0 );
					if( $show_new_product_carousel == 1):
						?><!-- End $showdeal/$deal verification -->
						
						
						<?php 
						$new_products_color_theme = get_theme_mod( 'set_new_colour_theme', 'dark' );
						$new_products_title = get_theme_mod( 'set_new_products');
						$new_products_set_number_of_products = get_theme_mod( 'set_new_num_products');

						echo do_shortcode('[flexslider_carousel color_theme="'.$new_products_color_theme.'" title="'.$new_products_title.'" number_of_products="'.$new_products_set_number_of_products.'" sort_type="new"]'); 
						?>
				<?php endif;
				
			endif;?>
				<!---------------------------------------------------------------------------------------------->
				<!-- End class_exists for WooCommerce -->

				<section class="about-me">
					<div class="container">
						<div class="row">
							<div class="col-12 col-md-6 about-me--image">
								<img src="<?php echo get_theme_mod('set_about_me_image'); ?>"/>
							</div>
							<div class="col-12 col-md-6">
							<div>
							<p class="description reveal">
							<?php echo get_theme_mod('set_about_me_description'); ?>
							<p>
							</div>
								<div class="cta cta-tertiary">
									<a href='<?php echo get_theme_mod('set_about_me_cta_url'); ?>'><?php echo get_theme_mod('set_about_me_cta_text'); ?></a>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="sustainable-living">
					<div class="container">
						<div class="row">
							<a href="/shop">
								<!-- <img src="" /> -->
								<div>
									<p>Sustainable living starts here.</p>
									<p>GO</p>
								</div>
							</a>
						</div>
					</div>
				</section>
			</main>
		</div>
<?php get_footer(); ?>