
     <?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package The Yorkshire Refill Company
 */

get_header();
?>
        <div class="content-area">
        <main>
           
            <div class="container">
                    <div class="row">
                    
                        <?php 
                            // If there are any posts
                            if(have_posts()):
                                    // Load posts loop
                                while(have_posts()): the_post();
                                ?>
                                <article <?php post_class(); ?>>
                                    <h2>
                                        <a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
                                    </h2>
                                    <div class="post-thumbnail">
                                        <?php 
                                            if(has_post_thumbnail()):
                                                the_post_thumbnail( 'the-yorkshire-refill-co-blog', array('class' => 'img-fluid') );
                                            endif;
                                        ?>
                                    </div>
                                    <div class="meta">
                                        <p>Published by <?php the_author_posts_link(); ?> on <?php echo get_the_date(); ?>
                                        <?php if(has_category()): ?>
                                        <br />
                                        Categories: <span><?php the_category(' '); ?></span>
                                        <?php endif; ?>
                                        <?php if(has_tag()): ?>
                                        <br />
                                        Tags: <span><?php the_tags('', ','); ?></span>
                                        <?php endif; ?>
                                        </p>
                                    </div>
                                    <div><?php the_excerpt(); ?></div>
                                </article>
                                <?php
                                endwhile;
                            else:
                        ?>
                        <div class="page-404">
                            <div class="page-404__copy">
                                <h1>Oops!<br/>Looks like this page doesn't exist!</h1>
                                    <p>You can go back to our <a href='/'>Hompage</a> or checkout some of our <a href='/shop'>products</a>!</p>
                                    <p>In fact, here's a little taster of our newest products...</p>
                                    
                                </div>
                                    <?php echo do_shortcode('[flexslider_carousel color_theme="light" title="New Products" number_of_products="10" sort_type="new"]'); ?>
                        </div>
                        <?php 
                            endif
                        ?>

                    </div>
                </div>
        </main>
        </div>
        <?php get_footer()?>