<?php 

/*
Template Name: Coming Soon
*/

?>

	<!DOCTYPE html>
	<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
	<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
	<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
	<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
	<html>
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<title></title>
			<meta name="description" content="">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
			<link rel="preconnect" href="https://fonts.gstatic.com">
			<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400&display=swap" rel="stylesheet">
			<style>
			*{
				font-family: 'Montserrat', sans-serif;
				color: white;
				font-weight: 300;
			}
			html{
				background-color: #9d6e56;
			}
			html, body{
				height: 100%;
				overflow: hidden;
			}
			body{
				margin: 0;
				display: flex;
				align-items: center;
				justify-content: center;
				letter-spacing: 0.1em;

			}
			body:after{
				content:'';
				background-image: url('/wp-content/uploads/2020/12/PATTERN-WHITE-960x1024.png');
				opacity: 0.08;
				position: absolute;
				top: 0;
				left: 0;
				height: 100%;
				width: 100%;
				background-size: contain;
				pointer-events: none;

			}
			.content-area{
				margin-top: 100px;
			}
			.post-thumbnail{
				width: 90%;
				margin: auto;

			}
			.post-thumbnail img{
				width: 100%;
				height: auto;
				margin: auto;
			}
			.fa {
				padding: 16px;
				font-size: 30px;
				width: 30px;
				text-align: center;
				text-decoration: none;
				margin: 5px 10px;
				border-radius: 30px;
			}
			.fa:hover {
				opacity: 0.7;
			}
			.fa-facebook {
				background: #3B5998;
				color: white;
			}

			.fa-twitter {
				background: #55ACEE;
				color: white;
			}
			.fa-instagram {
				background: #125688;
				color: white;
			}
			.social{
				text-align: center;
				margin-top: 50px;
				position: relative;
			}
			h1{
				font-size: 18px;
			} 
			p{
				font-size: 16px;
			}
			/* .wp-block-group{
				position: absolute;
				top: -128px;
				opacity: 0.1;
				left: 0;
				right: 0;
			} */

			p span{
				font-weight: bold;
			}

			.wp-block-image{
				width: 100%;
				margin: auto;
				bottom: 10vw;
				position: relative;
				pointer-events: none;
			}
			
			@media screen and (min-width: 768px){
				
				.wp-block-image{
					position: relative;
					bottom: 100px;
				}
				.post-thumbnail{
					width: 70%;
					margin: auto;
				}
				h1{
				font-size: 26px;
				} 
				p{
					font-size: 20px;
				}
			} 

			.page-template-template-comingsoon #moove_gdpr_cookie_modal, .page-template-template-comingsoon #moove_gdpr_cookie_info_bar{
				display: none;
			}

			</style>
		</head>
		<body <?php body_class() ?>>
			<!--[if lt IE 7]>
				<p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
			<![endif]-->

			<div class="content-area">
        <main>
           
            <div class="container">
                    <div class="row">
                    
                        <?php 
                            // If there are any posts
                            if(have_posts()):
                                    // Load posts loop
                                while(have_posts()): the_post();
                                ?>
                                <article <?php post_class(); ?>>
                                    <div class="post-thumbnail">
                                        <?php 
                                            if(has_post_thumbnail()):
                                                the_post_thumbnail( 'the-yorkshire-refill-co-blog', array('class' => 'img-fluid') );
											endif;
											the_content();
                                        ?>
                                    </div>
                                </article>
                                <?php
                                endwhile;
                            else:
                        ?>
                        <p>Nothing to display</p>
                        <?php 
                            endif
                        ?>

                    </div>
                </div>
        </main>
        </div>
			<script src="" async defer></script>
			
		<?php wp_footer(); ?>
		</body>
	</html>
