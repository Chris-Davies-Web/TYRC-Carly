<?php 

/*
Template Name: How We Work
*/

get_header(); ?>

		<div class="content-area how-we-work-landing">
			<main>
				<section class="how-we-work-hero">
					<div class="container">
						<div class="row">
							<div class="col-12 col-md-6 hww-image">
								<img src="<?php echo get_theme_mod('set_how_we_work_hero_image'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 hww-text">
								<h1><?php echo get_theme_mod('set_how_we_work_title'); ?></h1>
							</div>
						</div>
					</div>
				</section>
				<section class="how-we-work-steps">
					<div class="container">
						<div class="row">
							<div class="col-12 col-md-6 hww-image">
								<img src="<?php echo get_theme_mod('set_how_we_work_image_step_1'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 hww-text">
								<h2><?php echo get_theme_mod('set_how_we_work_title_step_1'); ?></h2>
								<p><?php echo get_theme_mod('set_how_we_work_description_step_1'); ?></p>
							</div>
						</div>
						<div class="row">
							<div class="col-12 col-md-6 hww-image">
								<img src="<?php echo get_theme_mod('set_how_we_work_image_step_2'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 hww-text">
								<h2><?php echo get_theme_mod('set_how_we_work_title_step_2'); ?></h2>
								<p><?php echo get_theme_mod('set_how_we_work_description_step_2'); ?></p>
							</div>
						</div>
						<div class="row">
							<div class="col-12 col-md-6 hww-image">
								<img src="<?php echo get_theme_mod('set_how_we_work_image_step_3'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 hww-text">
								<h2><?php echo get_theme_mod('set_how_we_work_title_step_3'); ?></h2>
								<p><?php echo get_theme_mod('set_how_we_work_description_step_3'); ?></p>
							</div>
						</div>
						<div class="row">
							<div class="col-12 col-md-6 hww-image">
								<img src="<?php echo get_theme_mod('set_how_we_work_image_step_4'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 hww-text">
								<h2><?php echo get_theme_mod('set_how_we_work_title_step_4'); ?></h2>
								<p><?php echo get_theme_mod('set_how_we_work_description_step_4'); ?></p>
							</div>
						</div>
						<div class="row" id="how-we-work-points">
							<div class="col-12 col-md-12 hww-text hww-points" >
								<h2><?php echo get_theme_mod('set_how_we_work_points_explanation_title'); ?></h2>
								<p><?php echo get_theme_mod('set_how_we_work_points_explanation_description'); ?></p>
							</div>
						</div>
					</div>
				</section>
			</main>
		</div>
<?php get_footer(); ?>