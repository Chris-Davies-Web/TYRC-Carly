<?php 

/*
Template Name: About
*/

get_header(); ?>

		<div class="content-area about">
			<main>
				<section class="about-hero">
					<div class="container">
						<div class="row">
							<img src="<?php echo get_theme_mod('set_about_me_hero_image'); ?>" alt="" />
							<p class="description">
								<?php echo get_theme_mod('set_about_me_hero_text'); ?>
							<p>
						</div>
					</div>
				</section>
				<section class="about-blocks blocks">
					<div class="container">
						<div class="row">
							<div class="col-12 col-md-6">
								<img src="<?php echo get_theme_mod('set_about_me_row_one_image'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 about-text">
								<h1><?php echo get_theme_mod('set_about_me_row_one_header'); ?></h1>
								<p><?php echo get_theme_mod('set_about_me_row_one_text'); ?></p>
							</div>
						</div>
						<div class="row">
							<div class="col-12 col-md-6">
								<img src="<?php echo get_theme_mod('set_about_me_row_two_image'); ?>" alt="" />
							</div>
							<div class="col-12 col-md-6 about-quote">
								<p><?php echo get_theme_mod('set_about_me_row_two_text'); ?></p>
							</div>
						</div>
					</div>
				</section>
				<section class="sustainable-living">
					<div class="container">
						<div class="row">
							<a href="/shop">
								<div>
									<p>Sustainable living starts here.</p>
									<p>GO</p>
								</div>
							</a>
						</div>
					</div>
				</section>
				
			
			</main>
		</div>
<?php get_footer(); ?>