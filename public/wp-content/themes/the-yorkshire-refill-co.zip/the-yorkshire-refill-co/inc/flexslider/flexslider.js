// Can also be used with $(document).ready()
jQuery(window).load(function () {

    var newArrivalsSlider = jQuery('.flexslider.new-arrivals');
    newArrivalsSlider.flexslider({
        animation: "slide",
        animationLoop: false,
        itemWidth: 150,
        itemMargin: 30,
        minItems: 2,
        maxItems: 4
    });
});