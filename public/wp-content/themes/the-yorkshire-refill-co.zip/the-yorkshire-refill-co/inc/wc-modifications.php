<?php 
/**
 * Template Overrides for WooCommerce pages
 *
 * @link https://docs.woocommerce.com/document/woocommerce-theme-developer-handbook/#section-3
 *
 * @package The Yorkshire Refill Company
 */

function the_yorkshire_refill_co_wc_modify(){
	/** 
	* Modify WooCommerce opening and closing HTML tags
	* We need Bootstrap-like opening/closing HTML tags
	*/
	add_action( 'woocommerce_before_main_content', 'the_yorkshire_refill_co_open_container_row', 5 );
	function the_yorkshire_refill_co_open_container_row(){
		echo '<div class="container shop-content"><div class="row">';
	}

	add_action( 'woocommerce_after_main_content', 'the_yorkshire_refill_co_close_container_row', 5 );
	function the_yorkshire_refill_co_close_container_row(){
		echo '</div></div>';
	}

	/** 
	* Remove the main WC sidebar from its original position
	* We'll be including it somewhere else later on
	*/
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar' );

	if( is_shop() ){

		// add_action( 'woocommerce_before_main_content', 'the_yorkshire_refill_co_add_sidebar_tags', 6 );
		// function the_yorkshire_refill_co_add_sidebar_tags(){
		// 	echo '<div class="sidebar-shop col-lg-3 col-md-4 order-2 order-md-1">';
		// }

		// Put the main WC sidebar back, but using other action hook and on a different position
		//add_action( 'woocommerce_before_main_content', 'woocommerce_get_sidebar', 7 );
		// add_action( 'woocommerce_before_main_content', 'add_custom_sidebar', 7 );
		// function add_custom_sidebar(){
		// 	if ( is_active_sidebar( "custom-side-bar" ) ){
		// 		echo '<div id="primary-sidebar" class="primary-sidebar widget-area" role="complementary">';
		// 		dynamic_sidebar( "custom-side-bar" );
		// 		echo '</div>';
		// 	}
		// }

		add_action( 'woocommerce_before_shop_loop', 'the_yorkshire_refill_co_add_categories', 8 );
		function the_yorkshire_refill_co_add_categories(){
			$args = array(
				'taxonomy' => 'product_cat',
				'hide_empty'=> 0,
				'orderby' => 'name',
				'order' => 'ASC'
				);
			   
			   $categories = get_categories($args);
			   echo "<div class='category-container'><a class='category active' href='#!' data-slug=''>All products</a>";
			   
			   foreach($categories as $category) { 
				   if($category->slug !== "uncategorized"){
				   
						echo "<a class='category' href='#!' data-slug='".$category->slug."'>".$category->name."</a>";
				   }
			  
				 wp_reset_postdata();
			   }
			   echo "</div>";
			   // Search form
			   echo do_shortcode('[wcas-search-form]');
			   
		}
		

		// add_action( 'woocommerce_before_main_content', 'the_yorkshire_refill_co_close_sidebar_tags', 8 );
		// function the_yorkshire_refill_co_close_sidebar_tags(){
		// 	echo '</div>';
		// }
		// Also, if we are on a shop page, include the product description
		add_action( 'woocommerce_after_shop_loop_item_title', 'the_excerpt', 1 );	
		
		
		// Add a custom sort select box
		//add_action( 'woocommerce_before_shop_loop', 'the_yorkshire_refill_co_add_custom_sort', 8 );
		function the_yorkshire_refill_co_add_custom_sort(){
			
			   echo '<div class="custom-sort-container">
						<select name="sort-products" id="sort-products" data-category="">
							<option value="date">Newest</option>
							<option value="popularity" selected>Most Popular</option>
							<option value="rating">Average Rating</option>
							<option value="price">Price: Low to High</option>
							<option value="price-desc">Price: High to Low</option>
						</select>
					</div>';
			// echo '<div class="custom-sort-container">
			// 		<select name="orderby" class="orderby" aria-label="Shop order">
			// 				<option value="popularity">Sort by popularity</option>
			// 				<option value="rating">Sort by average rating</option>
			// 				<option value="date" selected="selected">Newest</option>
			// 				<option value="price">Sort by price: low to high</option>
			// 				<option value="price-desc">Sort by price: high to low</option>
			// 		</select>
			// 	</div>';
					
			   
		}

		// Add filters 
		add_action( 'woocommerce_before_shop_loop', 'the_yorkshire_refill_co_add_filter', 8 );
		function the_yorkshire_refill_co_add_filter(){
			echo "<div class='woo-filter-commerce-filter-button'><button>Filter and Sort</button></div>";
			echo do_shortcode('[wpf-filters id=1]');

		}

		

	}


	// Modify HTML tags on a shop page. We also want Bootstrap-like markup here (.primary div)
	add_action( 'woocommerce_before_main_content', 'the_yorkshire_refill_co_add_shop_tags', 9 );
	function the_yorkshire_refill_co_add_shop_tags(){
		if( is_shop()){
			echo '<div class="col-lg-12 col-md-12 order-1 order-md-2">';
		} else{
			echo '<div class="col">';
		}
	}
	add_action( 'woocommerce_after_main_content', 'the_yorkshire_refill_co_close_shop_tags', 4 );
	function the_yorkshire_refill_co_close_shop_tags(){
		echo '</div>';
	}
	
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		
}
add_action( 'wp', 'the_yorkshire_refill_co_wc_modify' );

// Remove default sort drop down
