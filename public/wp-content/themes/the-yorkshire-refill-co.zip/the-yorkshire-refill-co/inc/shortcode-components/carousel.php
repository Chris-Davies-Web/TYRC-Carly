<?php
    // Shortcode setup for a flexslider carousel
    // args
    // 1: colour theme
    // 2: title
    // 3: number of products
    // 4: orberby
    // 5:
    
 add_shortcode( 'flexslider_carousel', 'flexslider_carousel_shortcode' );
 //function flexslider_carousel_shortcode($atts, $content, $tag){
function flexslider_carousel_shortcode($atts){
    if($atts['sort_type'] === "new"){
        $a = shortcode_atts( array(
            'color_theme' => 'light',
            'title' => 'New Arrivals',
            'section_classes' => 'new-products',
            'number_of_products' => '10'
        ), $atts );

        $args = array(
            'post_type'			=> 'product',
            'posts_per_page'    => esc_attr($a['number_of_products']),
            'orderby' 			=> 'date',
            'order' 			=> 'DESC',
            'meta_query' 		=> array(
                array(
                    'key' => '_stock_status',
                    'value' => 'instock'
                )
            ),
        );
        
    } else if($atts['sort_type'] === "favourites"){
        $a = shortcode_atts( array(
            'color_theme' => 'light',
            'title' => 'Customer Favourites',
            'section_classes' => 'popular-products',
        ), $atts );
        
        $args = array(
            'post_type'			=> 'product',
            'posts_per_page'	=> esc_attr($a['number_of_products']),
            'meta_key'  	    => 'total_sales',
            'orderby'   	    => 'meta_value_num',
            'order' 			=> 'desc',
            'meta_query' 		=> array(
                array(
                    'key' => '_stock_status',
                    'value' => 'instock'
                )
            ),
        );
    }
    
    $slider_loop = new WP_Query( $args );
    if( $slider_loop->have_posts() ):
    echo ' <section class="'. esc_attr($a['section_classes']) .' '. esc_attr( $a['color_theme']) .' ">
                <h2 class="slider-title">'. esc_attr( $a['title']) .'</h2>
                <div class="flexslider new-arrivals">
                    <ul class="slides">';
                        while( $slider_loop->have_posts() ):
                            $slider_loop->the_post();
                            wc_get_template_part( "content", "product" );  
                        endwhile;
                        wp_reset_postdata();
                        echo '
                    </ul>
                </div>
            </section>';
    

        endif;
 }
