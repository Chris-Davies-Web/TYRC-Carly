<?php

// Our Brands Settings Panel
$wp_customize->add_panel( 'our_brands_panel', array(
    'priority'       => 10,
     'theme_supports' => '',
     'title'          => 'Customise Our Brands Page',
     'description'    => 'Customise the Our Brands Content',
   ) );


/** ----------------------------------------------------------------------- */

// Our Brands Hero Settings
$wp_customize->add_section(
    'sec_our_brands_hero', array(
        'title'			=> 'Hero Settings',
        'description'	=> 'Hero Section',
        'panel'         => 'our_brands_panel'
    )
);

       

        // Field 1 - Hero Image
        $wp_customize->add_setting(
            'set_our_brands_hero_image', array(
                'type'					=> 'theme_mod',
                'default'				=> '',
                'sanitize_callback'		=> 'sanitize_text_field'
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Image_Control( $wp_customize, 'set_our_brands_hero_image', array(
                'label' => 'Upload Hero Image',
                'section' => 'sec_our_brands_hero',
                'settings' => 'set_our_brands_hero_image',
                'button_labels' => array(// All These labels are optional
                            'select' => 'Select Hero Image',
                            'remove' => 'Remove  Hero Image',
                            'change' => 'Change  Hero Image',
                            )
            ))
        );

         // Field 2 - Hero Text
			$wp_customize->add_setting(
				'set_our_brands_hero_title', array(
					'type'					=> 'theme_mod',
					'default'				=> '',
					'sanitize_callback'		=> 'sanitize_text_field'
				)
			);

			$wp_customize->add_control(
				'set_our_brands_hero_title', array(
					'label'			=> 'Hero Text',
					'description'	=> 'Add the hero text here',
					'section'		=> 'sec_our_brands_hero',
					'type'			=> 'text'
				)
            );

             // Field 2 - Page Title
			$wp_customize->add_setting(
				'set_our_brands_title', array(
					'type'					=> 'theme_mod',
					'default'				=> '',
					'sanitize_callback'		=> 'sanitize_text_field'
				)
			);

			$wp_customize->add_control(
				'set_our_brands_title', array(
					'label'			=> 'Page title',
					'description'	=> 'Add the page title here',
					'section'		=> 'sec_our_brands_hero',
					'type'			=> 'text'
				)
            );

?>