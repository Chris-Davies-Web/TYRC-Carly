
<?php
// About Settings Panel
$wp_customize->add_panel( 'basket_panel', array(
    'priority'       => 10,
     'theme_supports' => '',
     'title'          => 'Customise Basket Page',
     'description'    => 'Customise the Basket Content',
   ) );

// About Us Hero Settings
$wp_customize->add_section(
    'basket_notification', array(
        'title'			=> 'Notification Settings',
        'description'	=> 'Notification Section',
        'panel'         => 'basket_panel'
    )
);

  // Field 2 - Hero Text
  $wp_customize->add_setting(
    'basket_notification_text', array(
        'type'					=> 'theme_mod',
        'default'				=> '',
        'sanitize_callback'		=> 'my_sanitation'
    )
);

$wp_customize->add_control(
    'basket_notification_text', array(
        'label'			=> 'Basket Notification Text',
        'description'	=> 'Add the basket notification text here',
        'section'		=> 'basket_notification',
        'type'			=> 'textarea'
    )
);


       
?>