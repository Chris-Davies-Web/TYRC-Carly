<?php

// How We Work Settings Panel
$wp_customize->add_panel( 'how_we_work_panel', array(
    'priority'       => 10,
     'theme_supports' => '',
     'title'          => 'Customise How We Work Page',
     'description'    => 'Customise the How We Work Content',
   ) );


/** ----------------------------------------------------------------------- */

// How We Work Hero Settings
$wp_customize->add_section(
    'sec_how_we_work_hero', array(
        'title'			=> 'Hero Settings',
        'description'	=> 'Hero Section',
        'panel'         => 'how_we_work_panel'
    )
);

       

        // Field 1 - Hero Image
        $wp_customize->add_setting(
            'set_how_we_work_hero_image', array(
                'type'					=> 'theme_mod',
                'default'				=> '',
                'sanitize_callback'		=> 'sanitize_text_field'
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Image_Control( $wp_customize, 'set_how_we_work_hero_image', array(
                'label' => 'Upload Hero Image',
                'section' => 'sec_how_we_work_hero',
                'settings' => 'set_how_we_work_hero_image',
                'button_labels' => array(// All These labels are optional
                            'select' => 'Select Hero Image',
                            'remove' => 'Remove  Hero Image',
                            'change' => 'Change  Hero Image',
                            )
            ))
        );

         // Field 2 - Hero Text
			$wp_customize->add_setting(
				'set_how_we_work_title', array(
					'type'					=> 'theme_mod',
					'default'				=> '',
					'sanitize_callback'		=> 'sanitize_text_field'
				)
			);

			$wp_customize->add_control(
				'set_how_we_work_title', array(
					'label'			=> 'Hero Text',
					'description'	=> 'Add the how we hero text here',
					'section'		=> 'sec_how_we_work_hero',
					'type'			=> 'text'
				)
            );


/** ----------------------------------------------------------------------- */
// How We Work Steps
$wp_customize->add_section(
    'sec_how_we_work_steps', array(
        'title'			=> 'How We Work Steps',
        'description'	=> 'How We Work Steps',
        'panel'         => 'how_we_work_panel'
    )
);
for($x = 1; $x <=4; $x++){

    // Field 1 - Hero Image
    $wp_customize->add_setting(
        'set_how_we_work_image_step_'.$x, array(
            'type'					=> 'theme_mod',
            'default'				=> '',
            'sanitize_callback'		=> 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Image_Control( $wp_customize, 'set_how_we_work_image_step_'.$x, array(
            'label' => 'Upload Image Step '.$x,
            'section' => 'sec_how_we_work_steps',
            'settings' => 'set_how_we_work_image_step_'.$x,
            'button_labels' => array(// All These labels are optional
                        'select' => 'Select Image Image',
                        'remove' => 'Remove  Image Image',
                        'change' => 'Change  Image Image',
                        )
        ))
    );

    // Field 2 - How we work title
        $wp_customize->add_setting(
            'set_how_we_work_title_step_'.$x, array(
                'type'					=> 'theme_mod',
                'default'				=> '',
                'sanitize_callback'		=> 'sanitize_text_field'
            )
        );

        $wp_customize->add_control(
            'set_how_we_work_title_step_'.$x, array(
                'label'			=> 'How we work header - Step '.$x,
                // 'description'	=> 'How we work header - step '.$x,
                'section'		=> 'sec_how_we_work_steps',
                'type'			=> 'text'
            )
        );
    // Field 3 - How we work description
    $wp_customize->add_setting(
        'set_how_we_work_description_step_'.$x, array(
            'type'					=> 'theme_mod',
            'default'				=> '',
            'sanitize_callback'		=> 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_how_we_work_description_step_'.$x, array(
            'label'			=> 'How we work description - Step '.$x,
            // 'description'	=> 'How we work description - step '.$x,
            'section'		=> 'sec_how_we_work_steps',
            'type'			=> 'text'
        )
    );
}

/** ----------------------------------------------------------------------- */

// How we work points copy
$wp_customize->add_section(
    'sec_how_we_work_points', array(
        'title'			=> 'How the points work',
        'description'	=> 'How the points work',
        'panel'         => 'how_we_work_panel'
    )
);
// Field 1 - How we work points title
$wp_customize->add_setting(
    'set_how_we_work_points_explanation_title', array(
        'type'					=> 'theme_mod',
        'default'				=> '',
        'sanitize_callback'		=> 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    'set_how_we_work_points_explanation_title', array(
        'label'			=> 'How we work - Points Header',
        'section'		=> 'sec_how_we_work_points',
        'type'			=> 'text'
    )
);
// Field 2 - How we work points description
$wp_customize->add_setting(
'set_how_we_work_points_explanation_description', array(
    'type'					=> 'theme_mod',
    'default'				=> '',
    'sanitize_callback'		=> 'my_sanitation'
)
);

$wp_customize->add_control(
'set_how_we_work_points_explanation_description', array(
    'label'			=> 'How we work - Points Description',
    'section'		=> 'sec_how_we_work_points',
    'type'			=> 'textarea'
)
);
function my_sanitation( $text ) {
    return addslashes( $text );
 }
   ?>
