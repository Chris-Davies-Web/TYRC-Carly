<?php

// About Settings Panel
$wp_customize->add_panel( 'about_us_panel', array(
    'priority'       => 10,
     'theme_supports' => '',
     'title'          => 'Customise About Us Page',
     'description'    => 'Customise the About Us Content',
   ) );


/** ----------------------------------------------------------------------- */

// About Us Hero Settings
$wp_customize->add_section(
    'sec_about_hero', array(
        'title'			=> 'Hero Settings',
        'description'	=> 'Hero Section',
        'panel'         => 'about_us_panel'
    )
);

       

        // Field 1 - Hero Image
        $wp_customize->add_setting(
            'set_about_me_hero_image', array(
                'type'					=> 'theme_mod',
                'default'				=> '',
                'sanitize_callback'		=> 'sanitize_text_field'
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Image_Control( $wp_customize, 'set_about_me_hero_image', array(
                'label' => 'Upload Hero Image',
                'priority' => 20,
                'section' => 'sec_about_hero',
                'settings' => 'set_about_me_hero_image',
                'button_labels' => array(// All These labels are optional
                            'select' => 'Select Hero Image',
                            'remove' => 'Remove  Hero Image',
                            'change' => 'Change  Hero Image',
                            )
            ))
        );

         // Field 2 - Hero Text
			$wp_customize->add_setting(
				'set_about_me_hero_text', array(
					'type'					=> 'theme_mod',
					'default'				=> '',
					'sanitize_callback'		=> 'sanitize_text_field'
				)
			);

			$wp_customize->add_control(
				'set_about_me_hero_text', array(
					'label'			=> 'Hero Text',
					'description'	=> 'Add the about me hero text here',
					'section'		=> 'sec_about_hero',
					'type'			=> 'text'
				)
            );


/** ----------------------------------------------------------------------- */
// About Us  Settings
$wp_customize->add_section(
    'sec_about_content', array(
        'title'			=> 'About Us Settings',
        'description'	=> 'About Us Section',
        'panel'         => 'about_us_panel'
    )
);

// Field 1 - Hero Image
$wp_customize->add_setting(
    'set_about_me_row_one_image', array(
        'type'					=> 'theme_mod',
        'default'				=> '',
        'sanitize_callback'		=> 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize, 'set_about_me_row_one_image', array(
        'label' => 'Upload row one Image',
        'section' => 'sec_about_content',
        'settings' => 'set_about_me_row_one_image',
        'button_labels' => array(// All These labels are optional
                    'select' => 'Select Hero Image',
                    'remove' => 'Remove  Hero Image',
                    'change' => 'Change  Hero Image',
                    )
    ))
);

 // Field 2 - Hero Text
    $wp_customize->add_setting(
        'set_about_me_row_one_header', array(
            'type'					=> 'theme_mod',
            'default'				=> '',
            'sanitize_callback'		=> 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_about_me_row_one_header', array(
            'label'			=> 'Row one header',
            'description'	=> 'Row one header',
            'section'		=> 'sec_about_content',
            'type'			=> 'text'
        )
    );

    // Field 3 - Hero Text
    $wp_customize->add_setting(
        'set_about_me_row_one_text', array(
            'type'					=> 'theme_mod',
            'default'				=> '',
            'sanitize_callback'		=> 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_about_me_row_one_text', array(
            'label'			=> 'Row one text',
            'description'	=> 'Row one text',
            'section'		=> 'sec_about_content',
            'type'			=> 'text'
        )
    );

    /** ----------------------------------------------------------------------- */
// Field 1 - Hero Image
$wp_customize->add_setting(
    'set_about_me_row_two_image', array(
        'type'					=> 'theme_mod',
        'default'				=> '',
        'sanitize_callback'		=> 'sanitize_text_field'
    )
);

$wp_customize->add_control(
    new WP_Customize_Image_Control( $wp_customize, 'set_about_me_row_two_image', array(
        'label' => 'Upload row two Image',
        'section' => 'sec_about_content',
        'settings' => 'set_about_me_row_two_image',
        'button_labels' => array(// All These labels are optional
                    'select' => 'Select Hero Image',
                    'remove' => 'Remove  Hero Image',
                    'change' => 'Change  Hero Image',
                    )
    ))
);

 // Field 2 - Hero Text
    $wp_customize->add_setting(
        'set_about_me_row_two_header', array(
            'type'					=> 'theme_mod',
            'default'				=> '',
            'sanitize_callback'		=> 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_about_me_row_two_header', array(
            'label'			=> 'Row two header',
            'description'	=> 'Row two header',
            'section'		=> 'sec_about_content',
            'type'			=> 'text'
        )
    );

    // Field 3 - Hero Text
    $wp_customize->add_setting(
        'set_about_me_row_two_text', array(
            'type'					=> 'theme_mod',
            'default'				=> '',
            'sanitize_callback'		=> 'sanitize_text_field'
        )
    );

    $wp_customize->add_control(
        'set_about_me_row_two_text', array(
            'label'			=> 'Row two text',
            'description'	=> 'Row two text',
            'section'		=> 'sec_about_content',
            'type'			=> 'text'
        )
    );

   ?>
