// Category Filter
jQuery(document).ready(function() {

    // Shop Category Filters
    jQuery('.woocommerce .category-container .category').on('click', function (e) {
        e.preventDefault();
        // Get category 
       

        // Set active state
        var categories = jQuery('.woocommerce .category-container .category');
        jQuery(categories).each(function() {
            jQuery(this).removeClass('active');
        });

        jQuery(this).addClass('active');


        var category = jQuery(this).attr('data-slug');


        if (category === "") {
            // Remove selected
            jQuery('[data-filter-type="wpfCategory"] .wpfCheckbox').each(function () {
                if (jQuery(this).find('input').prop('checked')) {
                    jQuery(this).find('input').click();
                    return;
                }
            })
        } else {
            // Remove all checked
            jQuery('[data-filter-type="wpfCategory"]').each(function () {
                jQuery(this).find('input').prop('checked', false);
            })
            jQuery('[data-filter-type="wpfCategory"] [data-term-slug="'+category+'"] input').click();
        }
       
      
      //  var category = jQuery(this).data('slug');

      //  var sortBy = jQuery('.woocommerce #sort-products').val();

       // filterByCategory(category, sortBy);


    });


    function filterByCategory(category, sortBy) {
        // Get products
        jQuery.ajax({
            type: 'POST',
            url: '/wp-admin/admin-ajax.php',
            dataType: 'html',
            data: {
                action: 'filter_by_category',
                category: category,
                sortBy: sortBy
            },
            success: function(res) {
                // Setu products
                var productsContainer = jQuery('.products');
                productsContainer.html(res);

                // Set number of items
                jQuery('.woocommerce-result-count').html('Showing all ' + productsContainer[0].children.length + ' products');

                // Set category for sort
                jQuery('#sort-products').attr('data-category', category);
            }
        })
    }

    // Shop Order By Sort
    jQuery('.woocommerce #sort-products').on('change', function() {
        // Get category
        var category = jQuery('.woocommerce #sort-products').attr('data-category');
        var sortBy = jQuery('.woocommerce #sort-products').val();

        filterByCategory(category, sortBy);

    });

    // Fade in
    /* Every time the window is scrolled ... */
    jQuery(window).scroll(function() {
        // Reveal items with 'reveal' class
        revealItems();

        // Setup header
        if (jQuery(window).scrollTop() > 200) {
            jQuery('#page > header').addClass('scrolled');
        } else {
            jQuery('#page > header').removeClass('scrolled');
        }

    });

    // Filter functionality
    jQuery('.woo-filter-commerce-filter-button button').click(function () {
        jQuery('body').addClass('filters-open');
        jQuery('html').addClass('filters-open');
    })

    function revealItems() {
        jQuery('.reveal').each(function(i) {
            var item = jQuery(this);
            var delay = jQuery(item).attr('data-delay') ? jQuery(item).attr('data-delay') : 200;
            var isMobile = window.innerWidth < 768 ? true : false;

            if (isMobile) {
                delay = 0;
            }

            var middleOfObject = jQuery(item).offset().top + (jQuery(item).outerHeight() / 2);
            var bottom_of_window = jQuery(window).scrollTop() + jQuery(window).height();

            /* If the object is completely visible in the window, fade it it */
            if (bottom_of_window > middleOfObject) {
                setTimeout(function() {
                    jQuery(item).animate({ 'opacity': '1' }, 800);
                }, delay);


            }

        });
    }
    revealItems();
})