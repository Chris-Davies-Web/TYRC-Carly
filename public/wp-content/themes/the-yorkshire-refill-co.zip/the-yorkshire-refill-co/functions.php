<?php 
/**
 * The Yorkshire Refill Company functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package The Yorkshire Refill Company
 */

 // Responsive Nav
 require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';

// Customizer config
require_once get_template_directory() . '/inc/customizer.php';


// Add shortcodes
//function shortcodes_init(){
require_once get_template_directory() . '/inc/shortcode-components/carousel.php';
//}
//add_action('init', 'shortcodes_init');


function the_yorkshire_refill_co_scripts(){
    
    wp_enqueue_script( 'global', get_template_directory_uri() . '/inc/js/global.js' , true);
    wp_enqueue_script( 'bootstrap-js', get_template_directory_uri() . '/inc/bootstrap.min.js' ,  '4.5.3', true);
    wp_enqueue_style( 'bootstrap-css', get_template_directory_uri() . '/inc/bootstrap.min.css', array(), '4.5.3', 'all');
    wp_enqueue_style( 'the-yorkshire-refill-co-style', get_stylesheet_uri(), array(), '1.0', 'all');

    // Fonts
    //wp_enqueue_style( 'google-fonts', 'https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&display=swap&family=Seaweed+Script&display=swap' );
    wp_enqueue_style( 'Quentin', get_template_directory_uri() . '/inc/fonts/Quentin.woff' );

    // Flexslider JS and CSS
    
    wp_enqueue_script( 'flexslider-min-js', get_template_directory_uri() . '/inc/flexslider/jquery.flexslider-min.js' , '', true);
    wp_enqueue_script( 'flexslider-js', get_template_directory_uri() . '/inc/flexslider/flexslider.js' ,  '', true);
    wp_enqueue_style( 'flexslider-css', get_template_directory_uri() . '/inc/flexslider/flexslider.css', array(), '', 'all');
}

add_action( 'wp_enqueue_scripts', 'the_yorkshire_refill_co_scripts' );

function the_yorkshire_refill_co_config(){
    register_nav_menus( 
        array(
            'the_yorkshire_refill_co_main_menu' => 'Main Menu',
            'the_yorkshire_refill_co_footer_menu' => 'Footer Menu',
            'the_yorkshire_refill_co_get_around_menu' => 'Get Around Footer Menu',
            'the_yorkshire_refill_co_follow_us_menu' => 'Follow Us Footer Menu',

        )
     );

     add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 255,
        'single_image_width' => 655,
        'product_grid' => array(
            'default_rows'      => 10,
            'min_rows'          => 5,
            'max_rows'          => 10,
            'default_columns'   => 4,
            'min_columns'       => 4,
            'max_columns'       => 4
        )
     ));
     add_theme_support( 'wc-product-gallery-zoom');
     add_theme_support( 'wc-product-gallery-lighbox');
     add_theme_support( 'wc-product-gallery-slider');
     add_theme_support( 'custom-logo', array(
         'height' => 85,
         'width' => 160,
         'flex_height' => true,
         'flex_width' => true,
     ));

     add_image_size('the_yorkshire_refill_co_slider', 1920, 800, array('center', 'center'));


     if(!isset($content_width)){
         $content_width = 600;
     }

     // Remove downloads from WOocommerce
     add_filter( 'woocommerce_account_menu_items', 'custom_remove_downloads_my_account', 999 );
 
    function custom_remove_downloads_my_account( $items ) {
        unset($items['downloads']);
        return $items;
    }

    add_action("woocommerce_before_cart_contents", "checkout_message");

    function checkout_message( ) {
        if(get_theme_mod('basket_notification_text') !== ""){
            echo "<div class='basket-notification'>";
            echo wp_kses_post(get_theme_mod('basket_notification_text'));
            echo "</div>";
        }
    }

}

add_action('after_setup_theme', 'the_yorkshire_refill_co_config', 0);

/* if WooCommerce is active in the theme, include the WooCommerce modification */
if( class_exists('WooCommerce')){
    require get_template_directory() . '/inc/wc-modifications.php';
}

/**
 * Show cart contents / total Ajax
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'the_yorkshire_refill_co_woocommerce_header_add_to_cart_fragment' );

function the_yorkshire_refill_co_woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;

	ob_start();

	?>
	<span class="items"><?php echo WC()->cart->get_cart_contents_count();?></span>
	<?php
	$fragments['span.items'] = ob_get_clean();
	return $fragments;
}

// Client Custom Post Type
// Our custom post type function
function create_posttype() {
 
    register_post_type( 'brands',
    // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Brands' ),
                'singular_name' => __( 'Brand' )
            ),
            'supports'            => array( 'title' ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'brands'),
            'show_in_rest' => true,
            'show_in_admin_bar'   => true,
 
        )
    );
}

function wpb_widgets_init() {
 
        register_sidebar(
            array (
                'name' => __( 'Custom Sidebar Area', 'your-theme-domain' ),
                'id' => 'custom-side-bar',
                'description' => __( 'This is the custom sidebar that you registered using the code snippet. You can change this text by editing this section in the code.', 'your-theme-domain' ),
                'before_widget' => '<div class="widget-content">',
                'after_widget' => "</div>",
                'before_title' => '<h3 class="widget-title">',
                'after_title' => '</h3>',
            )
        );
 
}
add_action( 'widgets_init', 'wpb_widgets_init' );
// Hooking up our function to theme setup
add_action( 'init', 'create_posttype' );

// Shop AJAX Filter
function filter_by_category() {
    $catSlug = $_POST['category'];
    $sortBy = $_POST['sortBy'];

    $ajaxposts = new WP_Query([
      'post_type'       => 'product',
      'posts_per_page'  => -1,
      'order'           => 'ASC',
      'product_cat'     => $catSlug,
      'orderby'         => $sortBy
    ]);
    

    $res = '';
  
    if($ajaxposts->have_posts()) {
      while($ajaxposts->have_posts()) : $ajaxposts->the_post();
        $res.= woocommerce_get_template_part( 'content', 'product' ); 
      endwhile;
    } else {
        $res.= '<h3 class="no-products">There are no products in this category, try another one!</h3>';
    }
    // global $wp_query;
    // echo "Page Numbers ".$ajaxposts->max_num_pages;
    // echo "WPPage Numbers ".$wp_query->max_num_pages;
    // $wp_query->max_num_pages=$ajaxposts->max_num_pages;

    //echo $res;
    
    //echo $sortBy;
    exit;
  }
  add_action('wp_ajax_filter_by_category', 'filter_by_category');
  add_action('wp_ajax_nopriv_filter_by_category', 'filter_by_category');

  // Shop AJAX Sort Option
//   function sort_filtered_category() {
//     $catSlug = $_POST['category'];
//     $sortBy = $_POST['sortBy'];
  
//     $ajaxposts = new WP_Query([
//       'post_type' => 'product',
//       'posts_per_page' => -1,
//       'orderby' => 'date', 
//       'order' => $sortBy,
//       'product_cat' => $catSlug
//     ]);
    

//     $res = '';
  
//     if($ajaxposts->have_posts()) {
//       while($ajaxposts->have_posts()) : $ajaxposts->the_post();
//         $res.= woocommerce_get_template_part( 'content', 'product' ); 
//       endwhile;
//     } else {
//         $res.= '<h3 class="no-products">There are no products in this category, try another one!</h3>';
//     }

//     echo $res;
//     exit;
//   }
//   add_action('wp_ajax_filter_by_category', 'sort_filtered_category');
//   add_action('wp_ajax_nopriv_filter_by_category', 'sort_filtered_category');

// Redirects to Homepage
add_action( 'template_redirect', 'tyrc_redirect_post' );

function tyrc_redirect_post() {
    // Redirect singular brands to our-brands page
    if ( is_singular( 'brands' ) || get_post_type() === 'brands') {
        wp_redirect( '/our-brands', 301 );
        exit;
      }
}
