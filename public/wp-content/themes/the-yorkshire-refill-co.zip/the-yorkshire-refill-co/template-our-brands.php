<?php 

/*
Template Name: Our Brands
*/

get_header(); ?>

		<div class="content-area our-brands">
			<main>
				<section class="our-brands-hero">
					<div class="container">
						<div class="row">
							<!-- <div class="col-12 col-md-6 ob-image">
								<img src="<?php //echo get_theme_mod('set_our_brands_hero_image'); ?>" alt="" />
							</div> -->
							<div class="col-12 col-md-12 ob-text">
								<h1><?php echo get_theme_mod('set_our_brands_hero_title'); ?></h1>
							</div>
						</div>
					</div>
				</section>
				<section>
					
				<h2><?php echo get_theme_mod('set_our_brands_title'); ?></h2>
					<div class="container">
					<div class="row">
				<?php 
					$args = array( 'post_type' => 'brands', 'posts_per_page' => 10 );
					$the_query = new WP_Query( $args ); 
				?>
				<?php if ( $the_query->have_posts() ) : ?>
					<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
					<div class="brand col-12 md-col-6">
						<div class="brand-image">
							<?php 
							$image = get_field("brand_image"); 
							$size = "full";
							if($image): ?>
								<img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
							<?php endif; ?>	
							<p class="image-brand-name"><?php echo the_field("brand_name"); ?></p>
							<div class="brand-overlay">
								<h2><?php echo the_field("brand_owners"); ?></h2>
								<p class="brand-name"><?php echo the_field("brand_name"); ?></p>
								<p class="brand-description"><?php echo the_field("brand_description"); ?></p>
							</div>
						</div>
						
					</div>
					<?php endwhile; else:  ?>
						<p><?php _e( 'Sorry, no brands matched your criteria.' ); ?></p>
					<?php endif; ?>
					</div>
					</div>
					
				</section>
				<?php echo do_shortcode('[flexslider_carousel color_theme="light" title="Newest Products" number_of_products="10" sort_type="new"]'); ?>
			</main>
		</div>
<?php get_footer(); ?>